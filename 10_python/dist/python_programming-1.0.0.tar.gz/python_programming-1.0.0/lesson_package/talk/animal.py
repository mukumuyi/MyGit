# from lesson_package.tools import utils
from ..tools import utils

def sing():
    return '###fjiatiskfjwe'

def cry():
    return utils.say_twice('fjagehaio')